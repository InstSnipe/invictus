# Changelog (1.18.2 Releases)


### 1.2.0 (11/27/23)
* The models used for the Shotgun and Medium Scope are now respectively used for the Pump Shotgun and Chevron Scope in NZGE.
  As a result, these two items have received changes:
  -  The Shotgun's model is edited to resemble a Benelli M4 semi-automatic shotgun, aligning with its default stats.
  -  The Medium Scope now uses its original model again with a new reticle design.
* Updated the Pistol model - made its overall length a bit shorter and repositioned the front sight.
* Changed the Shotgun's sounds to match its new model.
* Changed the Rifle's fire sound, to better suit the sound of a semi-automatic rifle.
* Moved the .cgmmeta parameter tweaks for the NZGE Hunting Rifle to the recently added Bolt Action Rifle.
* Model adjustments to the Tactical Stocks.

NOTICE: The file name format has been changed to "(name)_(release number)_(game version)" to be consistent with the file name format used for NZGE.

### 1.1.1 (6/17/23)
* Updated enchanted gun fire sounds to reduce the volume of the 'laser gun' sound samples. This matches the changed made in NZGE v1.2.2.

### 1.1.0 (6/6/23)
This version was developed from chemlzh's unofficial 1.18.2 port on github, and used with permission. Thanks!

* Initial release for 1.18.2 with full parity with the other 1.1.0 releases.
* Added Simplified Chinese (zh_cn) translation, courtesy of chemlzh on github.